package com.mycompany.part3;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.*;
import java.util.regex.Pattern;

public class PART3 {
    private JFrame frame;
    private JPanel mainPanel;
    private CardLayout cardLayout;

    private Map<String, String> users = new HashMap<>(); // username -> hashed password
    private Map<String, String> userPhoneNumbers = new HashMap<>(); // username -> phone
    private boolean isLoggedIn = false;
    private String currentUser = null;

    private ArrayList<String> activityLog = new ArrayList<>();

    // For storing messages with IDs
    private ArrayList<Message> messages = new ArrayList<>();

    // Quiz questions: {question, answer}
    private final String[][] QUIZ_QUESTIONS = {
            {"What is phishing?", "a scam to get sensitive info"},
            {"What makes a strong password?", "uppercase digits special"},
            {"What is 2FA?", "two-factor authentication"},
    };

    // For task reminders
    private Map<String, String> reminders = new HashMap<>();

    // Message class to hold ID and content
    private static class Message {
        String id;
        String content;

        Message(String id, String content) {
            this.id = id;
            this.content = content;
        }
    }

    public PART3() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("Cybersecurity Awareness Chatbot - Part 3");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setSize(600, 400);

        cardLayout = new CardLayout();
        mainPanel = new JPanel(cardLayout);

        mainPanel.add(loginPanel(), "login");
        mainPanel.add(registerPanel(), "register");
        mainPanel.add(appPanel(), "app");

        frame.add(mainPanel);
        frame.setLocationRelativeTo(null);
        frame.setVisible(true);

        showLogin();
    }

    // Panels

    private JPanel loginPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lblUser = new JLabel("Username:");
        JLabel lblPass = new JLabel("Password:");

        JTextField txtUser = new JTextField(15);
        JPasswordField txtPass = new JPasswordField(15);

        JButton btnLogin = new JButton("Login");
        JButton btnRegister = new JButton("Register");

        JLabel lblMessage = new JLabel(" ");

        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(lblUser, gbc);

        gbc.gridx = 1;
        panel.add(txtUser, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(lblPass, gbc);

        gbc.gridx = 1;
        panel.add(txtPass, gbc);

        gbc.gridx = 1; gbc.gridy = 2;
        panel.add(btnLogin, gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        panel.add(btnRegister, gbc);

        gbc.gridx = 1; gbc.gridy = 4;
        panel.add(lblMessage, gbc);

        btnLogin.addActionListener(e -> {
            String username = txtUser.getText().trim();
            String password = new String(txtPass.getPassword());

            if (username.isEmpty() || password.isEmpty()) {
                lblMessage.setText("Please fill all fields.");
                return;
            }

            if (!users.containsKey(username)) {
                lblMessage.setText("User not found.");
                return;
            }

            String hashedInput = hashPassword(password);
            if (!users.get(username).equals(hashedInput)) {
                lblMessage.setText("Incorrect password.");
                return;
            }

            isLoggedIn = true;
            currentUser = username;
            lblMessage.setText("Login successful.");
            logActivity("User logged in: " + username);

            txtUser.setText("");
            txtPass.setText("");
            showApp();
        });

        btnRegister.addActionListener(e -> showRegister());

        return panel;
    }

    private JPanel registerPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();

        JLabel lblUser = new JLabel("Username:");
        JLabel lblPass = new JLabel("Password:");
        JLabel lblPhone = new JLabel("Cellphone (+27XXXXXXXXX):");

        JTextField txtUser = new JTextField(15);
        JPasswordField txtPass = new JPasswordField(15);
        JTextField txtPhone = new JTextField(15);

        JButton btnRegister = new JButton("Register");
        JButton btnBack = new JButton("Back");

        JLabel lblMessage = new JLabel(" ");

        gbc.insets = new Insets(5, 5, 5, 5);

        gbc.gridx = 0; gbc.gridy = 0;
        panel.add(lblUser, gbc);

        gbc.gridx = 1;
        panel.add(txtUser, gbc);

        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(lblPass, gbc);

        gbc.gridx = 1;
        panel.add(txtPass, gbc);

        gbc.gridx = 0; gbc.gridy = 2;
        panel.add(lblPhone, gbc);

        gbc.gridx = 1;
        panel.add(txtPhone, gbc);

        gbc.gridx = 1; gbc.gridy = 3;
        panel.add(btnRegister, gbc);

        gbc.gridx = 1; gbc.gridy = 4;
        panel.add(btnBack, gbc);

        gbc.gridx = 1; gbc.gridy = 5;
        panel.add(lblMessage, gbc);

        btnRegister.addActionListener(e -> {
            String username = txtUser.getText().trim();
            String password = new String(txtPass.getPassword());
            String phone = txtPhone.getText().trim();

            if (username.isEmpty() || password.isEmpty() || phone.isEmpty()) {
                lblMessage.setText("Please fill all fields.");
                return;
            }

            if (!checkUserName(username)) {
                lblMessage.setText("Username must contain '_' and be max 5 chars.");
                return;
            }

            if (!checkPasswordComplexity(password)) {
                lblMessage.setText("Password must be 8+ chars with uppercase, digit & special char.");
                return;
            }

            if (!checkCellPhoneNumber(phone)) {
                lblMessage.setText("Phone must be +27 followed by 9 digits.");
                return;
            }

            if (users.containsKey(username)) {
                lblMessage.setText("Username already exists.");
                return;
            }

            users.put(username, hashPassword(password));
            userPhoneNumbers.put(username, phone);
            lblMessage.setText("Registration successful.");
            logActivity("User registered: " + username);

            txtUser.setText("");
            txtPass.setText("");
            txtPhone.setText("");
        });

        btnBack.addActionListener(e -> showLogin());

        return panel;
    }

    private JPanel appPanel() {
        JPanel panel = new JPanel(new BorderLayout());

        // Top label
        JLabel lblWelcome = new JLabel("Welcome! Select an option.", SwingConstants.CENTER);
        panel.add(lblWelcome, BorderLayout.NORTH);

        // Buttons for features
        JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        JButton btnSendMessage = new JButton("Send Message");
        JButton btnViewMessages = new JButton("View/Delete Messages");
        JButton btnQuiz = new JButton("Cybersecurity Quiz");
        JButton btnTaskAssistant = new JButton("Task Assistant");
        JButton btnChatBot = new JButton("Chatbot");
        JButton btnActivityLog = new JButton("Activity Log");
        JButton btnLogout = new JButton("Logout");

        buttonPanel.add(btnSendMessage);
        buttonPanel.add(btnViewMessages);
        buttonPanel.add(btnQuiz);
        buttonPanel.add(btnTaskAssistant);
        buttonPanel.add(btnChatBot);
        buttonPanel.add(btnActivityLog);

        panel.add(buttonPanel, BorderLayout.CENTER);
        panel.add(btnLogout, BorderLayout.SOUTH);

        btnSendMessage.addActionListener(e -> sendMessage());
        btnViewMessages.addActionListener(e -> manageMessages());
        btnQuiz.addActionListener(e -> runQuiz());
        btnTaskAssistant.addActionListener(e -> taskAssistant());
        btnChatBot.addActionListener(e -> chatBot());
        btnActivityLog.addActionListener(e -> viewActivityLog());

        btnLogout.addActionListener(e -> {
            isLoggedIn = false;
            currentUser = null;
            logActivity("User logged out.");
            showLogin();
        });

        return panel;
    }

    // Show panels
    private void showLogin() {
        cardLayout.show(mainPanel, "login");
    }

    private void showRegister() {
        cardLayout.show(mainPanel, "register");
    }

    private void showApp() {
        cardLayout.show(mainPanel, "app");
    }

    // --- Feature implementations ---

    // Send a message
    private void sendMessage() {
        if (!isLoggedIn) return;

        String id = JOptionPane.showInputDialog(frame, "Enter message ID:");
        if (id == null || id.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Message ID cannot be empty.");
            return;
        }
        for (Message m : messages) {
            if (m.id.equals(id)) {
                JOptionPane.showMessageDialog(frame, "Message ID already exists.");
                return;
            }
        }

        String content = JOptionPane.showInputDialog(frame, "Enter message content:");
        if (content == null || content.trim().isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Message content cannot be empty.");
            return;
        }

        messages.add(new Message(id, content));
        JOptionPane.showMessageDialog(frame, "Message sent and stored.");
        logActivity("User sent message with ID: " + id);
    }

    // View or delete messages
    private void manageMessages() {
        if (!isLoggedIn) return;

        if (messages.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No messages to show.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (Message m : messages) {
            sb.append("ID: ").append(m.id).append(" - ").append(m.content).append("\n");
        }

        String input = JOptionPane.showInputDialog(frame, "Messages:\n" + sb + "\nEnter ID to delete or leave blank to cancel:");
        if (input == null || input.trim().isEmpty()) return;

        boolean removed = messages.removeIf(m -> m.id.equals(input));
        if (removed) {
            JOptionPane.showMessageDialog(frame, "Message deleted.");
            logActivity("User deleted message ID: " + input);
        } else {
            JOptionPane.showMessageDialog(frame, "Message ID not found.");
        }
    }

    // Quiz
    private void runQuiz() {
        if (!isLoggedIn) return;

        int score = 0;
        for (String[] q : QUIZ_QUESTIONS) {
            String answer = JOptionPane.showInputDialog(frame, q[0]);
            if (answer != null && answer.toLowerCase().contains(q[1])) {
                score++;
            }
        }
        JOptionPane.showMessageDialog(frame, "Quiz finished! Your score: " + score + " out of " + QUIZ_QUESTIONS.length);
        logActivity("Completed quiz with score: " + score);
    }

    // Task assistant (add/view/delete reminders)
    private void taskAssistant() {
        if (!isLoggedIn) return;

        String[] options = {"Add Reminder", "View Reminders", "Delete Reminder", "Back"};
        String choice = (String) JOptionPane.showInputDialog(frame, "Task Assistant Menu:", "Task Assistant",
                JOptionPane.PLAIN_MESSAGE, null, options, options[0]);

        if (choice == null || choice.equals("Back")) return;

        switch (choice) {
            case "Add Reminder" -> {
                String task = JOptionPane.showInputDialog(frame, "Enter task name:");
                if (task == null || task.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Task name cannot be empty.");
                    return;
                }
                String time = JOptionPane.showInputDialog(frame, "Enter reminder time (e.g., 14:00):");
                if (time == null || time.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Reminder time cannot be empty.");
                    return;
                }
                reminders.put(task, time);
                JOptionPane.showMessageDialog(frame, "Reminder added.");
                logActivity("Added reminder: " + task + " at " + time);
            }
            case "View Reminders" -> {
                if (reminders.isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "No reminders set.");
                } else {
                    StringBuilder sb = new StringBuilder();
                    reminders.forEach((task, time) -> sb.append(task).append(" at ").append(time).append("\n"));
                    JOptionPane.showMessageDialog(frame, sb.toString(), "Reminders", JOptionPane.INFORMATION_MESSAGE);
                }
            }
            case "Delete Reminder" -> {
                String task = JOptionPane.showInputDialog(frame, "Enter task name to delete:");
                if (task == null || task.trim().isEmpty()) return;
                if (reminders.remove(task) != null) {
                    JOptionPane.showMessageDialog(frame, "Reminder deleted.");
                    logActivity("Deleted reminder: " + task);
                } else {
                    JOptionPane.showMessageDialog(frame, "Reminder not found.");
                }
            }
        }
    }

    // Basic chatbot with simple NLP
    private void chatBot() {
        if (!isLoggedIn) return;

        String input = JOptionPane.showInputDialog(frame, "Ask the Cybersecurity Bot a question or type 'exit':");
        while (input != null && !input.equalsIgnoreCase("exit")) {
            String response = generateBotResponse(input);
            JOptionPane.showMessageDialog(frame, response);
            logActivity("Chatbot interaction: User asked \"" + input + "\" Bot responded \"" + response + "\"");
            input = JOptionPane.showInputDialog(frame, "Ask another question or type 'exit':");
        }
    }

    private String generateBotResponse(String input) {
        input = input.toLowerCase();
        if (input.contains("phishing")) {
            return "Phishing is a scam to get your sensitive info like passwords and credit card numbers.";
        } else if (input.contains("password")) {
            return "A strong password has uppercase letters, digits, special characters, and is at least 8 characters long.";
        } else if (input.contains("2fa") || input.contains("two-factor")) {
            return "Two-factor authentication adds an extra layer of security by requiring a code sent to your device.";
        } else if (input.contains("hello") || input.contains("hi")) {
            return "Hello! How can I assist you with cybersecurity today?";
        } else {
            return "Sorry, I don't understand that. Try asking about phishing, passwords, or two-factor authentication.";
        }
    }

    // View activity log
    private void viewActivityLog() {
        if (!isLoggedIn) return;

        if (activityLog.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "No activity yet.");
            return;
        }

        StringBuilder sb = new StringBuilder();
        for (String logEntry : activityLog) {
            sb.append(logEntry).append("\n");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(400, 300));

        JOptionPane.showMessageDialog(frame, scrollPane, "Activity Log", JOptionPane.INFORMATION_MESSAGE);
    }

    // Log activity with timestamp
    private void logActivity(String activity) {
        activityLog.add(new Date() + ": " + activity);
    }

    // Validation methods
    private boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    private boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) return false;
        if (!Pattern.compile("[A-Z]").matcher(password).find()) return false;
        if (!Pattern.compile("[0-9]").matcher(password).find()) return false;
        if (!Pattern.compile("[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]").matcher(password).find()) return false;
        return true;
    }

    private boolean checkCellPhoneNumber(String phone) {
        return phone.matches("^\\+27\\d{9}$");
    }

    private String hashPassword(String password) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashed = md.digest(password.getBytes());
            StringBuilder sb = new StringBuilder();
            for (byte b : hashed) {
                sb.append(String.format("%02x", b));
            }
            return sb.toString();
        } catch (NoSuchAlgorithmException e) {
            return null;
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PART3::new);
    }
}
